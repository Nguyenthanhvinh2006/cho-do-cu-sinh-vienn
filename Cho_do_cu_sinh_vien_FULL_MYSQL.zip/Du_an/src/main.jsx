import React,{useEffect,useState,createContext,useContext} from "react";
import {createRoot} from "react-dom/client";
import {BrowserRouter,useNavigate,useParams,useSearchParams,Link,Routes,Route,Navigate} from "react-router-dom";
import "./styles.css";

const API="http://localhost:3000/api";
const AuthContext=createContext();
function useAuth(){return useContext(AuthContext)}
function AuthProvider({children}){
  const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem("studentUser")||"null"));
  const login=(name="Sinh viên")=>{const u={id:1,name};setUser(u);localStorage.setItem("studentUser",JSON.stringify(u))};
  const logout=()=>{setUser(null);localStorage.removeItem("studentUser")};
  return <AuthContext.Provider value={{user,login,logout}}>{children}</AuthContext.Provider>
}
const money=n=>new Intl.NumberFormat("vi-VN").format(Number(n))+" đ";

function Layout(){
 const {user,logout}=useAuth();
 return <><header><Link className="logo" to="/">♻ Chợ Đồ Cũ</Link><nav>
  <Link to="/products">Mua đồ</Link><Link to="/post-product">Đăng tin</Link><Link to="/favorites">Yêu thích</Link><Link to="/messages">Tin nhắn</Link><Link to="/admin">Quản trị</Link>
  {user?<button onClick={logout}>Đăng xuất</button>:<Link to="/login">Đăng nhập</Link>}
 </nav></header><main><Routes>
 <Route path="/" element={<Home/>}/><Route path="/products" element={<Products/>}/><Route path="/products/:id" element={<ProductDetail/>}/>
 <Route path="/post-product" element={<ProductForm/>}/><Route path="/edit/:id" element={<ProductForm/>}/><Route path="/favorites" element={<Favorites/>}/>
 <Route path="/messages" element={<Messages/>}/><Route path="/profile/:id" element={<Profile/>}/><Route path="/admin" element={<Admin/>}/>
 <Route path="/login" element={<Login/>}/><Route path="*" element={<NotFound/>}/>
 </Routes></main><footer>© 2026 Chợ Đồ Cũ Sinh Viên · Mua bán tiết kiệm, an toàn và văn minh</footer></>
}

function Home(){return <section className="hero"><div><span className="tag">MARKETPLACE SINH VIÊN</span><h1>Mua bán đồ cũ<br/><b>Tiết kiệm hơn mỗi ngày</b></h1><p>Giáo trình, xe đạp, đồ học tập và nhiều sản phẩm hữu ích dành cho sinh viên.</p><Link className="primary" to="/products">Khám phá ngay →</Link></div><div className="hero-art">♻️<br/><small>REUSE · SAVE · SHARE</small></div></section>}

function Products(){
 const [params,setParams]=useSearchParams(); const [data,setData]=useState([]); const [loading,setLoading]=useState(true); const [error,setError]=useState("");
 const get=k=>params.get(k)||"";
 useEffect(()=>{setLoading(true);setError("");fetch(`${API}/products?${params}`).then(r=>r.ok?r.json():Promise.reject()).then(setData).catch(()=>setError("Không thể kết nối API")).finally(()=>setLoading(false))},[params.toString()]);
 const set=(k,v)=>{const p=new URLSearchParams(params);v?p.set(k,v):p.delete(k);setParams(p)};
 return <section><div className="page-title"><div><h2>Chợ đồ cũ</h2><p>Tìm sản phẩm phù hợp với bạn</p></div><Link className="primary" to="/post-product">+ Đăng tin</Link></div>
 <div className="filters"><input placeholder="🔎 Tìm kiếm..." value={get("search")} onChange={e=>set("search",e.target.value)}/>
 <select value={get("category")} onChange={e=>set("category",e.target.value)}><option value="">Tất cả danh mục</option><option>Sách</option><option>Xe đạp</option><option>Đồ học tập</option><option>Điện tử</option><option>Thời trang</option></select>
 <input type="number" placeholder="Giá từ" value={get("minPrice")} onChange={e=>set("minPrice",e.target.value)}/><input type="number" placeholder="Giá đến" value={get("maxPrice")} onChange={e=>set("maxPrice",e.target.value)}/>
 <select value={get("condition")} onChange={e=>set("condition",e.target.value)}><option value="">Tình trạng</option><option>Mới</option><option>Đã sử dụng</option></select>
 <select value={get("area")} onChange={e=>set("area",e.target.value)}><option value="">Khu vực</option><option>Cầu Giấy</option><option>Thanh Xuân</option><option>Đống Đa</option><option>Hai Bà Trưng</option></select>
 <select value={get("sort")} onChange={e=>set("sort",e.target.value)}><option value="">Tin mới nhất</option><option value="priceAsc">Giá thấp → cao</option><option value="priceDesc">Giá cao → thấp</option></select></div>
 {loading?<div className="notice">Đang tải dữ liệu...</div>:error?<div className="notice error">{error}</div>:<div className="grid">{data.map(p=><ProductCard key={p.id} p={p}/>)}</div>}
 </section>
}

function ProductCard({p}){const [fav,setFav]=useState(false);const toggle=()=>fetch(`${API}/favorites/${p.id}`,{method:"POST"}).then(r=>r.json()).then(x=>setFav(x.includes(p.id)));
 return <article className="card"><div className="pic">{p.images?.[0]?<img src={p.images[0].startsWith("http")?p.images[0]:"http://localhost:3000"+p.images[0]}/>:<span>📦</span>}</div><div className="card-body"><div className="row"><span className="pill">{p.category}</span><button className="heart" onClick={toggle}>{fav?"❤️":"♡"}</button></div><Link to={`/products/${p.id}`}><h3>{p.title}</h3></Link><p className="price">{money(p.price)}</p><p className="muted">📍 {p.area} · {p.condition}</p><small>👤 {p.seller}</small></div></article>}

function ProductDetail(){const {id}=useParams();const [p,setP]=useState(null);const [reason,setReason]=useState("");const [msg,setMsg]=useState("");const [fav,setFav]=useState(false);
 useEffect(()=>{fetch(`${API}/products/${id}`).then(r=>r.json()).then(setP)},[id]);
 if(!p)return <div className="notice">Đang tải...</div>;
 const report=()=>fetch(`${API}/reports`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productId:p.id,reason,note:msg})}).then(()=>alert("Đã gửi báo cáo"));
 return <section className="detail"><div className="detail-img">{p.images?.[0]?<img src={"http://localhost:3000"+p.images[0]}/>:<span>📦</span>}</div><div><span className="pill">{p.category}</span><h2>{p.title}</h2><div className="big-price">{money(p.price)}</div><p>{p.description}</p><p>📍 {p.area} · {p.condition}</p><p>Người bán: <Link to={`/profile/${p.sellerId}`}>{p.seller}</Link></p><div className="actions"><button onClick={()=>fetch(`${API}/favorites/${p.id}`,{method:"POST"}).then(()=>setFav(!fav))}>{fav?"❤️ Đã lưu":"♡ Lưu tin"}</button><Link className="primary" to="/messages">Nhắn người bán</Link><Link to={`/edit/${p.id}`}>✏ Sửa tin</Link></div><div className="report"><b>🚩 Báo cáo tin</b><select value={reason} onChange={e=>setReason(e.target.value)}><option value="">Chọn lý do</option><option>Tin giả</option><option>Giá không đúng</option><option>Nội dung không phù hợp</option><option>Sản phẩm bị cấm</option></select><input placeholder="Ghi chú" value={msg} onChange={e=>setMsg(e.target.value)}/><button onClick={report}>Gửi báo cáo</button></div></div></section>}

function ProductForm(){const {id}=useParams();const nav=useNavigate();const [form,setForm]=useState({title:"",description:"",price:"",condition:"Mới",category:"Sách",area:"Cầu Giấy"});const [files,setFiles]=useState([]);const [loading,setLoading]=useState(false);
 useEffect(()=>{if(id)fetch(`${API}/products/${id}`).then(r=>r.json()).then(p=>setForm(p))},[id]);
 const submit=e=>{e.preventDefault();if(!form.title||!form.description||Number(form.price)<=0)return alert("Vui lòng nhập đủ và đúng dữ liệu");setLoading(true);const fd=new FormData();Object.entries(form).forEach(([k,v])=>fd.append(k,v));files.forEach(f=>fd.append("images",f));fd.append("seller","Sinh viên");fd.append("sellerId","1");fetch(id?`${API}/products/${id}`:`${API}/products`,{method:id?"PUT":"POST",body:fd}).then(r=>{if(!r.ok)throw 0;return r.json()}).then(p=>nav(`/products/${p.id}`)).catch(()=>alert("Có lỗi khi lưu tin")).finally(()=>setLoading(false))};
 return <section className="form-page"><h2>{id?"Chỉnh sửa tin":"Đăng tin mới"}</h2><form onSubmit={submit}><label>Tiêu đề<input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label><label>Mô tả<textarea required value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><div className="two"><label>Giá<input required type="number" min="1" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/></label><label>Tình trạng<select value={form.condition} onChange={e=>setForm({...form,condition:e.target.value})}><option>Mới</option><option>Đã sử dụng</option></select></label></div><div className="two"><label>Danh mục<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}><option>Sách</option><option>Xe đạp</option><option>Đồ học tập</option><option>Điện tử</option><option>Thời trang</option></select></label><label>Khu vực<select value={form.area} onChange={e=>setForm({...form,area:e.target.value})}><option>Cầu Giấy</option><option>Thanh Xuân</option><option>Đống Đa</option><option>Hai Bà Trưng</option></select></label></div><label>Ảnh sản phẩm <input type="file" accept="image/*" multiple onChange={e=>setFiles([...e.target.files])}/></label><div className="previews">{files.map((f,i)=><img key={i} src={URL.createObjectURL(f)}/>)}</div><button className="primary" disabled={loading}>{loading?"Đang lưu...":"Lưu tin"}</button></form></section>}

function Favorites(){const [ids,setIds]=useState([]);const [data,setData]=useState([]);useEffect(()=>{fetch(`${API}/favorites`).then(r=>r.json()).then(setIds)},[]);useEffect(()=>{if(ids.length)fetch(`${API}/products`).then(r=>r.json()).then(a=>setData(a.filter(x=>ids.includes(x.id))))},[ids]);return <section><h2>❤️ Tin yêu thích</h2><div className="grid">{data.map(p=><ProductCard p={p} key={p.id}/>)}</div>{!data.length&&<div className="notice">Chưa có tin yêu thích.</div>}</section>}

function Messages(){const [text,setText]=useState("");const [data,setData]=useState([]);const load=()=>fetch(`${API}/messages`).then(r=>r.json()).then(setData);useEffect(()=>{load()},[]);const send=e=>{e.preventDefault();if(!text.trim())return;fetch(`${API}/messages`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({from:1,to:2,text})}).then(()=>{setText("");load()})};return <section className="messages"><h2>💬 Hộp thư</h2><div className="chat">{data.map(m=><div className="bubble" key={m.id}>{m.text}</div>)}</div><form onSubmit={send}><input placeholder="Nhập tin nhắn..." value={text} onChange={e=>setText(e.target.value)}/><button className="primary">Gửi</button></form></section>}

function Profile(){const {id}=useParams();const [u,setU]=useState(null);useEffect(()=>{fetch(`${API}/users/${id}`).then(r=>r.json()).then(setU)},[id]);if(!u)return <div className="notice">Đang tải...</div>;return <section><div className="profile"><div className="avatar">👤</div><div><h2>{u.name}</h2><p>{u.email}</p><p>⭐ {u.rating}/5 · Người bán trên Chợ Đồ Cũ</p></div></div><h2>Tin đang đăng</h2><div className="grid">{u.products.map(p=><ProductCard key={p.id} p={p}/>)}</div></section>}

function Admin(){const [stats,setStats]=useState(null);const [reports,setReports]=useState([]);const load=()=>{fetch(`${API}/stats`).then(r=>r.json()).then(setStats);fetch(`${API}/reports`).then(r=>r.json()).then(setReports)};useEffect(load,[]);const moderate=(id,status)=>fetch(`${API}/reports/${id}`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})}).then(load);return <section><h2>🛠 Quản trị hệ thống</h2>{stats&&<div className="stats"><div><b>{stats.total}</b><span>Tổng tin</span></div><div><b>{stats.active}</b><span>Đang bán</span></div><div><b>{stats.sold}</b><span>Đã bán</span></div><div><b>{stats.reports}</b><span>Báo cáo</span></div></div>}<div className="admin-box"><h3>Báo cáo cần xử lý</h3>{reports.length?reports.map(r=><div className="report-row" key={r.id}>Tin #{r.productId} · {r.reason} · <b>{r.status}</b><button onClick={()=>moderate(r.id,"approved")}>Duyệt</button><button onClick={()=>moderate(r.id,"removed")}>Gỡ tin</button></div>):<p>Chưa có báo cáo.</p>}</div></section>}

function Login(){const {login}=useAuth();const nav=useNavigate();const [name,setName]=useState("");return <section className="login"><h2>Đăng nhập</h2><input placeholder="Họ tên sinh viên" value={name} onChange={e=>setName(e.target.value)}/><button className="primary" onClick={()=>{login(name||"Sinh viên");nav("/")}}>Đăng nhập</button></section>}
function NotFound(){return <section className="notfound"><h1>404</h1><p>Trang bạn tìm không tồn tại.</p><Link className="primary" to="/">Về trang chủ</Link></section>}
function App(){return <AuthProvider><Layout/></AuthProvider>}
createRoot(document.getElementById("root")).render(<BrowserRouter><App/></BrowserRouter>);