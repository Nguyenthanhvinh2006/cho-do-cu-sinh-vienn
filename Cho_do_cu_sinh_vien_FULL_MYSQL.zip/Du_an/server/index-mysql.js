import express from "express";
import cors from "cors";
import multer from "multer";
import mysql from "mysql2/promise";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { fileURLToPath } from "url";

dotenv.config();
const __filename=fileURLToPath(import.meta.url), __dirname=path.dirname(__filename);
const app=express(), PORT=process.env.PORT||3000;
const uploadDir=path.join(__dirname,"uploads");
fs.mkdirSync(uploadDir,{recursive:true});

const pool=mysql.createPool({
 host:process.env.DB_HOST||"localhost",
 user:process.env.DB_USER||"root",
 password:process.env.DB_PASSWORD||"",
 database:process.env.DB_NAME||"cho_do_cu",
 waitForConnections:true,
 connectionLimit:10,
 charset:"utf8mb4"
});

app.use(cors()); app.use(express.json()); app.use("/uploads",express.static(uploadDir));
const storage=multer.diskStorage({
 destination:(_,__,cb)=>cb(null,uploadDir),
 filename:(_,file,cb)=>cb(null,`${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_")}`)
});
const upload=multer({storage});

const productSQL=`
 SELECT p.*, c.name category, u.name seller, u.rating,
        COALESCE(GROUP_CONCAT(pi.image_url),'') images
 FROM products p
 JOIN categories c ON c.id=p.category_id
 JOIN users u ON u.id=p.seller_id
 LEFT JOIN product_images pi ON pi.product_id=p.id
`;

function mapProduct(p){
 return {...p, price:Number(p.price), images:p.images?p.images.split(","):[]};
}

app.get("/api/products",async(req,res)=>{
 try{
  const {search,category,minPrice,maxPrice,condition,area,sort,status}=req.query;
  const where=[],params=[];
  if(search){where.push("(p.title LIKE ? OR p.description LIKE ?)");params.push(`%${search}%`,`%${search}%`)}
  if(category&&category!=="all"){where.push("c.name=?");params.push(category)}
  if(minPrice){where.push("p.price>=?");params.push(Number(minPrice))}
  if(maxPrice){where.push("p.price<=?");params.push(Number(maxPrice))}
  if(condition&&condition!=="all"){where.push("p.condition_status=?");params.push(condition)}
  if(area&&area!=="all"){where.push("p.area=?");params.push(area)}
  if(status){where.push("p.status=?");params.push(status)}
  let order="p.created_at DESC";
  if(sort==="priceAsc")order="p.price ASC";
  if(sort==="priceDesc")order="p.price DESC";
  const [rows]=await pool.query(productSQL+" "+(where.length?"WHERE "+where.join(" AND "):"")+" GROUP BY p.id ORDER BY "+order,params);
  res.json(rows.map(mapProduct));
 }catch(e){console.error(e);res.status(500).json({message:"Lỗi MySQL"})}
});

app.get("/api/products/:id",async(req,res)=>{
 try{
  const [rows]=await pool.query(productSQL+" WHERE p.id=? GROUP BY p.id",[req.params.id]);
  if(!rows.length)return res.status(404).json({message:"Không tìm thấy tin"});
  res.json(mapProduct(rows[0]));
 }catch(e){res.status(500).json({message:"Lỗi MySQL"})}
});

app.post("/api/products",upload.array("images",8),async(req,res)=>{
 try{
  const {title,description,price,condition,category,area,sellerId=1}=req.body;
  if(!title||!description||!price||!category||!area)return res.status(400).json({message:"Thiếu dữ liệu"});
  const [[cat]]=await pool.query("SELECT id FROM categories WHERE name=?",[category]);
  if(!cat)return res.status(400).json({message:"Danh mục không tồn tại"});
  const [r]=await pool.query("INSERT INTO products(title,description,price,condition_status,category_id,area,seller_id) VALUES(?,?,?,?,?,?,?)",
   [title,description,Number(price),condition||"Đã sử dụng",cat.id,area,Number(sellerId)]);
  for(const file of req.files||[])await pool.query("INSERT INTO product_images(product_id,image_url) VALUES(?,?)",[r.insertId,`/uploads/${file.filename}`]);
  const [rows]=await pool.query(productSQL+" WHERE p.id=? GROUP BY p.id",[r.insertId]);res.status(201).json(mapProduct(rows[0]));
 }catch(e){console.error(e);res.status(500).json({message:"Không thể tạo tin"})}
});

app.put("/api/products/:id",upload.array("images",8),async(req,res)=>{
 try{
  const {title,description,price,condition,category,area,status}=req.body;
  const [[cat]]=await pool.query("SELECT id FROM categories WHERE name=?",[category]);
  await pool.query("UPDATE products SET title=?,description=?,price=?,condition_status=?,category_id=?,area=?,status=COALESCE(?,status) WHERE id=?",
   [title,description,Number(price),condition,cat.id,area,status||null,req.params.id]);
  if(req.files?.length){
   await pool.query("DELETE FROM product_images WHERE product_id=?",[req.params.id]);
   for(const file of req.files)await pool.query("INSERT INTO product_images(product_id,image_url) VALUES(?,?)",[req.params.id,`/uploads/${file.filename}`]);
  }
  const [rows]=await pool.query(productSQL+" WHERE p.id=? GROUP BY p.id",[req.params.id]);res.json(mapProduct(rows[0]));
 }catch(e){console.error(e);res.status(500).json({message:"Không thể cập nhật"})}
});

app.delete("/api/products/:id",async(req,res)=>{
 try{const [r]=await pool.query("DELETE FROM products WHERE id=?",[req.params.id]);if(!r.affectedRows)return res.status(404).json({message:"Không tìm thấy tin"});res.json({message:"Đã xóa"})}
 catch(e){res.status(500).json({message:"Không thể xóa"})}
});

app.patch("/api/products/:id/status",async(req,res)=>{
 try{await pool.query("UPDATE products SET status=? WHERE id=?",[req.body.status,req.params.id]);const [rows]=await pool.query(productSQL+" WHERE p.id=? GROUP BY p.id",[req.params.id]);res.json(mapProduct(rows[0]))}
 catch(e){res.status(500).json({message:"Không thể đổi trạng thái"})}
});

app.get("/api/users/:id",async(req,res)=>{
 try{
  const [[u]]=await pool.query("SELECT id,name,email,rating,created_at FROM users WHERE id=?",[req.params.id]);
  if(!u)return res.status(404).json({message:"Không tìm thấy người bán"});
  const [products]=await pool.query(productSQL+" WHERE p.seller_id=? GROUP BY p.id ORDER BY p.created_at DESC",[req.params.id]);
  res.json({...u,products:products.map(mapProduct)});
 }catch(e){res.status(500).json({message:"Lỗi MySQL"})}
});

app.get("/api/favorites",async(req,res)=>{
 try{const [rows]=await pool.query("SELECT product_id FROM favorites WHERE user_id=1");res.json(rows.map(x=>x.product_id))}
 catch(e){res.status(500).json({message:"Lỗi MySQL"})}
});
app.post("/api/favorites/:id",async(req,res)=>{
 try{
  const [[x]]=await pool.query("SELECT * FROM favorites WHERE user_id=1 AND product_id=?",[req.params.id]);
  if(x)await pool.query("DELETE FROM favorites WHERE user_id=1 AND product_id=?",[req.params.id]);
  else await pool.query("INSERT INTO favorites(user_id,product_id) VALUES(1,?)",[req.params.id]);
  const [rows]=await pool.query("SELECT product_id FROM favorites WHERE user_id=1");res.json(rows.map(x=>x.product_id));
 }catch(e){res.status(500).json({message:"Lỗi MySQL"})}
});

app.get("/api/messages",async(req,res)=>{
 const [rows]=await pool.query("SELECT * FROM messages WHERE sender_id=1 OR receiver_id=1 ORDER BY created_at ASC");res.json(rows);
});
app.post("/api/messages",async(req,res)=>{
 const {from=1,to=2,text,productId=null}=req.body;
 if(!text)return res.status(400).json({message:"Tin nhắn trống"});
 const [r]=await pool.query("INSERT INTO messages(sender_id,receiver_id,product_id,content) VALUES(?,?,?,?)",[from,to,productId,text]);
 const [[m]]=await pool.query("SELECT * FROM messages WHERE id=?",[r.insertId]);res.status(201).json(m);
});

app.get("/api/reports",async(req,res)=>{const [rows]=await pool.query("SELECT * FROM reports ORDER BY created_at DESC");res.json(rows)});
app.post("/api/reports",async(req,res)=>{
 const {productId,reason,note=""}=req.body;
 const [r]=await pool.query("INSERT INTO reports(product_id,reporter_id,reason,note) VALUES(?,1,?,?)",[productId,reason,note]);
 res.status(201).json({id:r.insertId});
});
app.patch("/api/reports/:id",async(req,res)=>{
 await pool.query("UPDATE reports SET status=? WHERE id=?",[req.body.status,req.params.id]);res.json({message:"Đã cập nhật"});
});

app.get("/api/stats",async(req,res)=>{
 const [[a]]=await pool.query("SELECT COUNT(*) total FROM products");
 const [[b]]=await pool.query("SELECT COUNT(*) active FROM products WHERE status='active'");
 const [[c]]=await pool.query("SELECT COUNT(*) sold FROM products WHERE status='sold'");
 const [[d]]=await pool.query("SELECT COUNT(*) reports FROM reports");
 const [cats]=await pool.query("SELECT c.name category,COUNT(p.id) total FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id,c.name");
 const categories={};cats.forEach(x=>categories[x.category]=x.total);
 res.json({total:a.total,active:b.active,sold:c.sold,reports:d.reports,categories});
});

app.listen(PORT,()=>console.log(`MySQL API: http://localhost:${PORT}`));