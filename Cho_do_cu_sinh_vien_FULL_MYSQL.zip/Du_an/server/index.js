import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = 3000;
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_")}`)
});
const upload = multer({ storage });

let products = [
  {id:1,title:"Giáo trình Lập trình Web",description:"Giáo trình còn mới, phù hợp sinh viên CNTT.",price:70000,condition:"Đã sử dụng",category:"Sách",area:"Cầu Giấy",seller:"Nguyễn Văn An",sellerId:1,images:[],status:"active",createdAt:"2026-10-01T08:00:00Z",sold:false},
  {id:2,title:"Xe đạp sinh viên",description:"Xe đạp đi học, hoạt động tốt.",price:850000,condition:"Đã sử dụng",category:"Xe đạp",area:"Thanh Xuân",seller:"Trần Minh Đức",sellerId:2,images:[],status:"active",createdAt:"2026-09-30T10:00:00Z",sold:false},
  {id:3,title:"Balo laptop",description:"Balo chống sốc 15.6 inch.",price:180000,condition:"Mới",category:"Đồ học tập",area:"Đống Đa",seller:"Lê Thu Hà",sellerId:3,images:[],status:"active",createdAt:"2026-09-29T12:00:00Z",sold:false}
];
let users = [
  {id:1,name:"Nguyễn Văn An",email:"an@student.edu.vn",rating:4.8},
  {id:2,name:"Trần Minh Đức",email:"duc@student.edu.vn",rating:4.6},
  {id:3,name:"Lê Thu Hà",email:"ha@student.edu.vn",rating:4.9}
];
let favorites = [];
let messages = [];
let reports = [];

app.get("/api/products", (req,res)=>{
  let data = [...products];
  const {search,category,minPrice,maxPrice,condition,area,sort,status} = req.query;
  if(search) data=data.filter(p=>(p.title+" "+p.description).toLowerCase().includes(search.toLowerCase()));
  if(category && category!=="all") data=data.filter(p=>p.category===category);
  if(condition && condition!=="all") data=data.filter(p=>p.condition===condition);
  if(area && area!=="all") data=data.filter(p=>p.area===area);
  if(minPrice) data=data.filter(p=>p.price>=Number(minPrice));
  if(maxPrice) data=data.filter(p=>p.price<=Number(maxPrice));
  if(status) data=data.filter(p=>p.status===status);
  if(sort==="priceAsc") data.sort((a,b)=>a.price-b.price);
  else if(sort==="priceDesc") data.sort((a,b)=>b.price-a.price);
  else data.sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
  res.json(data);
});

app.get("/api/products/:id",(req,res)=>{
  const p=products.find(x=>x.id===Number(req.params.id));
  if(!p) return res.status(404).json({message:"Không tìm thấy tin"});
  res.json(p);
});

app.post("/api/products", upload.array("images",8), (req,res)=>{
  const {title,description,price,condition,category,area,seller,sellerId}=req.body;
  if(!title || !description || !price || !condition || !category || !area)
    return res.status(400).json({message:"Vui lòng nhập đầy đủ thông tin"});
  const images=(req.files||[]).map(f=>`/uploads/${f.filename}`);
  const item={id:Date.now(),title,description,price:Number(price),condition,category,area,seller:seller||"Sinh viên",sellerId:Number(sellerId)||1,images,status:"active",createdAt:new Date().toISOString(),sold:false};
  products.unshift(item);
  res.status(201).json(item);
});

app.put("/api/products/:id", upload.array("images",8), (req,res)=>{
  const idx=products.findIndex(x=>x.id===Number(req.params.id));
  if(idx<0) return res.status(404).json({message:"Không tìm thấy tin"});
  const old=products[idx];
  const images=req.files?.length ? req.files.map(f=>`/uploads/${f.filename}`) : old.images;
  products[idx]={...old,...req.body,id:old.id,price:Number(req.body.price),images,sold:req.body.status==="sold"||old.sold};
  res.json(products[idx]);
});

app.delete("/api/products/:id",(req,res)=>{
  const before=products.length;
  products=products.filter(x=>x.id!==Number(req.params.id));
  if(before===products.length) return res.status(404).json({message:"Không tìm thấy tin"});
  res.json({message:"Đã xóa"});
});

app.patch("/api/products/:id/status",(req,res)=>{
  const p=products.find(x=>x.id===Number(req.params.id));
  if(!p) return res.status(404).json({message:"Không tìm thấy tin"});
  p.status=req.body.status||"active";
  p.sold=p.status==="sold";
  res.json(p);
});

app.get("/api/users/:id",(req,res)=>{
  const u=users.find(x=>x.id===Number(req.params.id));
  if(!u) return res.status(404).json({message:"Không tìm thấy người bán"});
  res.json({...u,products:products.filter(p=>p.sellerId===u.id)});
});

app.get("/api/favorites",(req,res)=>res.json(favorites));
app.post("/api/favorites/:id",(req,res)=>{
  const id=Number(req.params.id);
  if(!favorites.includes(id)) favorites.push(id); else favorites=favorites.filter(x=>x!==id);
  res.json(favorites);
});

app.get("/api/messages",(req,res)=>res.json(messages));
app.post("/api/messages",(req,res)=>{
  const {from,to,text}=req.body;
  if(!text) return res.status(400).json({message:"Tin nhắn trống"});
  const m={id:Date.now(),from,to,text,createdAt:new Date().toISOString()};
  messages.push(m); res.status(201).json(m);
});

app.get("/api/reports",(req,res)=>res.json(reports));
app.post("/api/reports",(req,res)=>{
  const {productId,reason,note}=req.body;
  const r={id:Date.now(),productId:Number(productId),reason,note,status:"pending",createdAt:new Date().toISOString()};
  reports.push(r); res.status(201).json(r);
});
app.patch("/api/reports/:id",(req,res)=>{
  const r=reports.find(x=>x.id===Number(req.params.id));
  if(!r) return res.status(404).json({message:"Không tìm thấy báo cáo"});
  r.status=req.body.status||r.status; res.json(r);
});

app.get("/api/stats",(req,res)=>{
  const categories={};
  products.forEach(p=>categories[p.category]=(categories[p.category]||0)+1);
  res.json({
    total:products.length,
    active:products.filter(p=>p.status==="active").length,
    sold:products.filter(p=>p.sold).length,
    reports:reports.length,
    categories
  });
});

app.listen(PORT,()=>console.log(`API server: http://localhost:${PORT}`));