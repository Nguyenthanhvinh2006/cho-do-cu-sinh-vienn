# CHỢ ĐỒ CŨ SINH VIÊN — BẢN REACT + NODE/EXPRESS + MYSQL

## 1. Công nghệ
- ReactJS + React Router + Vite
- Node.js + Express
- MySQL
- mysql2
- Multer upload nhiều ảnh
- REST API

## 2. Dữ liệu ở đâu?
Dữ liệu nằm trong MySQL, KHÔNG còn là dữ liệu tạm trong RAM.

File:
`database/cho_do_cu.sql`

File này tạo:
- users
- categories
- products
- product_images
- favorites
- messages
- reports

và chèn sẵn dữ liệu mẫu.

## 3. Tạo database
Mở MySQL/phpMyAdmin rồi chạy toàn bộ file:
`database/cho_do_cu.sql`

Database:
`cho_do_cu`

Nếu dùng XAMPP: bật MySQL rồi mở phpMyAdmin -> Import file SQL.

## 4. Cấu hình MySQL
Copy `.env.example` thành `.env`.

Ví dụ MySQL root không có mật khẩu:
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=cho_do_cu
PORT=3000

Nếu root có mật khẩu thì điền:
DB_PASSWORD=mat_khau_mysql_cua_ban

## 5. Cài package
Trong thư mục project:
npm install

## 6. Chạy
npm run dev

Frontend:
http://localhost:5173

Backend:
http://localhost:3000

## 7. Dữ liệu mẫu
Sau khi import SQL, trang chợ đã có sẵn:
- Giáo trình Lập trình Web
- Xe đạp sinh viên
- Balo laptop
- Tai nghe Bluetooth
- Áo khoác sinh viên
- Máy tính Casio

Có sẵn user, yêu thích, tin nhắn và một báo cáo mẫu.

## 8. CRUD
CREATE: Đăng tin -> INSERT MySQL
READ: Danh sách/chi tiết -> SELECT MySQL
UPDATE: Sửa tin -> UPDATE MySQL
DELETE: Xóa tin -> DELETE MySQL

## 9. Lưu ý
Ảnh mẫu trong SQL là đường dẫn placeholder. Khi người dùng upload ảnh mới, ảnh thật được lưu trong `server/uploads`.
