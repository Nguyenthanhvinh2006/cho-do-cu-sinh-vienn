import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header style={{
      background: 'rgba(255, 255, 255, 0.9)',
      backdropFilter: 'blur(10px)',
      borderBottom: '1px solid #e2e8f0',
      padding: '15px 40px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'sticky',
      top: 0,
      zIndex: 1000
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span style={{ background: '#16a34a', color: 'white', padding: '6px 10px', borderRadius: '8px', fontWeight: 'bold', fontSize: '14px' }}>🛒</span>
        <h2 style={{ margin: 0, fontSize: '18px', fontWeight: '800', color: '#0f172a' }}>Cho Sinh Vien</h2>
      </div>

      <nav style={{ display: 'flex', gap: '30px', alignItems: 'center' }}>
        <Link to="/" style={{ color: '#475569', textDecoration: 'none', fontWeight: '600', fontSize: '14px' }}>Home</Link>
        <Link to="/shop" style={{ color: '#475569', textDecoration: 'none', fontWeight: '600', fontSize: '14px' }}>Marketplace</Link>
        <Link to="/post" style={{ color: '#475569', textDecoration: 'none', fontWeight: '600', fontSize: '14px' }}>Đăng bài</Link>
      </nav>

      <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
        <Link to="/shop" style={{ background: '#16a34a', color: 'white', padding: '8px 18px', borderRadius: '20px', textDecoration: 'none', fontWeight: '700', fontSize: '14px', boxShadow: '0 2px 8px rgba(22, 163, 74, 0.2)' }}>
          Vào chợ ngay
        </Link>
      </div>
    </header>
  );
}

export default Header;