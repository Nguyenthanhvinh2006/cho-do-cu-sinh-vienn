import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Header from './components/Header';
import Home from './pages/Home';
import Shop from './pages/Shop';
import PostProduct from './pages/PostProduct';
import ProductDetail from './pages/ProductDetail';

function App() {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('currentUser')) || null);
  const [products, setProducts] = useState([]);

  const fetchProducts = () => {
    fetch('http://localhost:5000/api/products')
      .then((res) => res.json())
      .then((data) => setProducts(data))
      .catch((err) => console.error('Lỗi tải dữ liệu:', err));
  };

  // Tải danh sách sản phẩm ngay khi người dùng đã đăng nhập (cả Admin và User)
  useEffect(() => {
    if (user) {
      fetchProducts();
    }
  }, [user]);

  const handleLoginSuccess = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setUser(null);
  };

  const handleAddProduct = (formData, onSuccess) => {
    fetch('http://localhost:5000/api/products', {
      method: 'POST',
      body: formData,
    })
      .then((res) => res.json())
      .then((savedProduct) => {
        setProducts((prev) => [savedProduct, ...prev]);
        if (onSuccess) onSuccess();
      })
      .catch((err) => console.error('Lỗi thêm sản phẩm:', err));
  };

  const handleDeleteProduct = (id) => {
    fetch(`http://localhost:5000/api/products/${id}`, {
      method: 'DELETE',
    })
      .then((res) => res.json())
      .then(() => {
        setProducts((prevProducts) => prevProducts.filter((item) => item.id !== id));
      })
      .catch((err) => console.error('Lỗi khi xóa:', err));
  };

  // 1. CHƯA ĐĂNG NHẬP -> HIỆN TRANG ĐĂNG NHẬP
  if (!user) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  // 2. ĐÃ ĐĂNG NHẬP LÀ ADMIN -> HIỆN TRANG QUẢN TRỊ ADMIN
  if (user.role === 'admin') {
    return (
      <div style={{ padding: '30px', fontFamily: 'Arial, sans-serif', background: '#f1f5f9', minHeight: '100vh' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#1e293b', color: '#fff', padding: '15px 25px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
          <h2>🛠️ Trang Quản Trị Hệ Thống (Admin Panel)</h2>
          <div>
            <span style={{ marginRight: '15px' }}>Xin chào, <b>{user.username}</b> (Admin)</span>
            <button 
              onClick={handleLogout} 
              style={{ background: '#ef4444', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', cursor: 'pointer', fontWeight: 'bold' }}
            >
              Đăng Xuất
            </button>
          </div>
        </div>

        <div style={{ marginTop: '30px', background: '#fff', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
          <h3>Quản lý tất cả sản phẩm rao bán trong hệ thống</h3>
          <p style={{ color: '#64748b', marginBottom: '20px' }}>Admin có quyền kiểm duyệt và xóa các bài đăng không phù hợp.</p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {products && products.length > 0 ? (
              products.map((item) => (
                <div key={item.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 15px', border: '1px solid #e2e8f0', borderRadius: '6px', background: '#fafafa' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                    <img 
                      src={item.image ? `http://localhost:5000${item.image}` : 'https://via.placeholder.com/50'} 
                      alt={item.title} 
                      style={{ width: '50px', height: '50px', objectFit: 'cover', borderRadius: '4px' }}
                    />
                    <div>
                      <h4 style={{ margin: '0 0 5px 0', color: '#1e293b' }}>{item.title}</h4>
                      <span style={{ color: '#dc2626', fontWeight: 'bold', fontSize: '14px' }}>{item.price}</span> 
                      <span style={{ color: '#64748b', fontSize: '13px', marginLeft: '10px' }}>({item.category})</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      if (window.confirm(`Bạn có chắc chắn muốn xóa sản phẩm "${item.title}" không?`)) {
                        handleDeleteProduct(item.id);
                      }
                    }}
                    style={{ background: '#dc2626', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '5px', cursor: 'pointer', fontSize: '13px', fontWeight: 'bold' }}
                  >
                    Xóa Bài
                  </button>
                </div>
              ))
            ) : (
              <p style={{ color: '#64748b' }}>Chưa có sản phẩm nào trên hệ thống.</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 3. ĐÃ ĐĂNG NHẬP LÀ SINH VIÊN (USER) -> HIỆN WEBSITE CHỢ ĐỒ CŨ ĐẦY ĐỦ
  return (
    <Router>
      <div className="app">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f8fafc', padding: '8px 20px', borderBottom: '1px solid #e2e8f0', fontSize: '14px' }}>
          <span>🎓 Sinh viên: <b>{user.username}</b></span>
          <button 
            onClick={handleLogout} 
            style={{ background: '#64748b', color: 'white', border: 'none', padding: '5px 10px', borderRadius: '4px', cursor: 'pointer', fontSize: '12px' }}
          >
            Đăng Xuất
          </button>
        </div>

        <Header />

        <Routes>
          <Route path="/" element={<Home products={products} />} />
          <Route path="/shop" element={<Shop products={products} />} />
          <Route path="/post" element={<PostProduct onAdd={handleAddProduct} />} />
          <Route path="/product/:id" element={<ProductDetail products={products} onDelete={handleDeleteProduct} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;