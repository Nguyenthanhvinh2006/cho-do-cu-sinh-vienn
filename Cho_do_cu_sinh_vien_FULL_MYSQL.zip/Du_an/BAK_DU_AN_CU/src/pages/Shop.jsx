import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Shop({ products }) {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const selectedCategory = queryParams.get('category');

  // Lọc sản phẩm theo danh mục nếu có trên URL, ngược lại hiển thị tất cả
  const filteredProducts = selectedCategory 
    ? products.filter(item => item.category === selectedCategory)
    : products;

  return (
    <div style={{ 
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      background: '#f8fafc', 
      minHeight: '100vh', 
      padding: '40px 20px' 
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        
        <div style={{ marginBottom: '30px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <span style={{ background: '#dcfce7', color: '#15803d', padding: '5px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '700' }}>
              MARKETPLACE
            </span>
            <h2 style={{ fontSize: '32px', fontWeight: '800', color: '#0f172a', margin: '10px 0 5px 0' }}>
              {selectedCategory ? `Danh mục: ${selectedCategory}` : 'Tất cả sản phẩm đang rao bán'}
            </h2>
            <p style={{ color: '#64748b', fontSize: '15px', margin: 0 }}>
              {selectedCategory ? `Các món đồ thuộc nhóm ${selectedCategory} từ sinh viên trong trường.` : 'Khám phá các món đồ cũ chất lượng từ sinh viên trong trường.'}
            </p>
          </div>

          {selectedCategory && (
            <Link to="/shop" style={{ background: '#e2e8f0', color: '#0f172a', padding: '8px 16px', borderRadius: '10px', textDecoration: 'none', fontSize: '14px', fontWeight: '600' }}>
              Xem tất cả sản phẩm
            </Link>
          )}
        </div>

        {filteredProducts.length === 0 ? (
          <div style={{ background: '#ffffff', padding: '50px', textAlign: 'center', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
            <p style={{ color: '#64748b', fontSize: '16px', marginBottom: '15px' }}>Hiện chưa có sản phẩm nào trong danh mục này.</p>
            <Link to="/shop" style={{ color: '#16a34a', fontWeight: 'bold', textDecoration: 'none' }}>Quay lại tất cả sản phẩm</Link>
          </div>
        ) : (
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', 
            gap: '25px' 
          }}>
            {filteredProducts.map((item) => (
              <div key={item.id} style={{ 
                background: '#ffffff', 
                borderRadius: '16px', 
                overflow: 'hidden', 
                boxShadow: '0 4px 12px rgba(0,0,0,0.03)',
                border: '1px solid #e2e8f0',
                transition: 'all 0.2s ease',
                display: 'flex',
                flexDirection: 'column'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)';
                e.currentTarget.style.boxShadow = '0 12px 24px rgba(0,0,0,0.08)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.03)';
              }}
              >
                <div style={{ height: '200px', background: '#f1f5f9', overflow: 'hidden' }}>
                  <img 
                    src={item.image ? `http://localhost:5000${item.image}` : 'https://via.placeholder.com/300'} 
                    alt={item.title} 
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                </div>

                <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', flexGrow: 1, justifyContent: 'space-between' }}>
                  <div>
                    <span style={{ fontSize: '11px', background: '#f1f5f9', color: '#475569', padding: '4px 10px', borderRadius: '6px', fontWeight: '700' }}>
                      {item.category}
                    </span>
                    <h4 style={{ margin: '12px 0 8px 0', fontSize: '16px', color: '#0f172a', fontWeight: '700', lineHeight: '1.4' }}>
                      {item.title}
                    </h4>
                    <p style={{ color: '#16a34a', fontWeight: '800', fontSize: '18px', margin: '0 0 15px 0' }}>
                      {item.price} đ
                    </p>
                  </div>

                  <Link to={`/product/${item.id}`} style={{ 
                    display: 'block', 
                    textAlign: 'center', 
                    background: '#0f172a', 
                    color: 'white', 
                    padding: '10px 0', 
                    borderRadius: '10px', 
                    textDecoration: 'none', 
                    fontWeight: '600',
                    fontSize: '14px',
                    transition: 'background 0.2s'
                  }}>
                    Xem chi tiết →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Shop;