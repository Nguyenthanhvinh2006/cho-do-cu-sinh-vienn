import React from 'react';
import { Link } from 'react-router-dom';

function Home({ products }) {
  return (
    <div style={{ 
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', 
      background: 'linear-gradient(135deg, #f0fdf4 0%, #f8fafc 100%)', 
      minHeight: '100vh',
      color: '#0f172a',
      paddingBottom: '60px'
    }}>
      
      {/* PHẦN HERO SECTION (BANNER CHÍNH) */}
      <div style={{ 
        maxWidth: '1200px', 
        margin: '0 auto', 
        padding: '60px 20px', 
        display: 'grid', 
        gridTemplateColumns: '1.2fr 0.8fr', 
        gap: '40px', 
        alignItems: 'center' 
      }}>
        
        {/* Cột bên trái: Tiêu đề và lời giới thiệu */}
        <div>
          <span style={{ 
            background: '#dcfce7', 
            color: '#15803d', 
            padding: '6px 14px', 
            borderRadius: '20px', 
            fontSize: '13px', 
            fontWeight: '600',
            display: 'inline-block',
            marginBottom: '20px'
          }}>
            Nơi mua bán riêng cho sinh viên
          </span>
          
          <h1 style={{ 
            fontSize: '48px', 
            fontWeight: '800', 
            lineHeight: '1.15', 
            margin: '0 0 20px 0',
            color: '#052e16'
          }}>
            Mua bán đồ cũ trong trường theo cách nhanh, đẹp và đáng tin hơn.
          </h1>
          
          <p style={{ 
            fontSize: '16px', 
            color: '#475569', 
            lineHeight: '1.6', 
            marginBottom: '30px' 
          }}>
            Từ giáo trình, laptop đến đồ phòng trọ. Mỗi giao dịch đều bắt đầu từ một cộng đồng nhỏ hơn, rõ người bán hơn và dễ hẹn gặp hơn.
          </p>
          
          <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
            <Link to="/shop" style={{ 
              background: '#16a34a', 
              color: 'white', 
              padding: '12px 24px', 
              borderRadius: '25px', 
              textDecoration: 'none', 
              fontWeight: 'bold',
              boxShadow: '0 4px 12px rgba(22, 163, 74, 0.3)',
              transition: 'background 0.2s'
            }}>
              Vào marketplace →
            </Link>
            <Link to="/post" style={{ 
              background: '#ffffff', 
              color: '#0f172a', 
              padding: '12px 24px', 
              borderRadius: '25px', 
              textDecoration: 'none', 
              fontWeight: '600',
              border: '1px solid #cbd5e1'
            }}>
              Đăng bán ngay
            </Link>
          </div>

          <div style={{ display: 'flex', gap: '20px', marginTop: '35px', fontSize: '13px', color: '#64748b', fontWeight: '500' }}>
            <span>🔒 Xác minh theo email trường</span>
            <span>💬 Chat theo từng sản phẩm</span>
            <span>⚡ Giá tốt hơn chợ rộng</span>
          </div>
        </div>

        {/* Cột bên phải: Bảng Market Pulse và Thẻ thống kê */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          
          <div style={{ 
            background: '#0f172a', 
            color: 'white', 
            padding: '25px', 
            borderRadius: '16px',
            boxShadow: '0 10px 25px rgba(15, 23, 42, 0.2)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <span style={{ fontSize: '11px', fontWeight: '700', letterSpacing: '1px', color: '#38bdf8' }}>MARKET PULSE</span>
              <span>✨</span>
            </div>
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '20px' }}>Sinh viên đang cần mua gì tuần này?</h3>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <div style={{ background: '#1e293b', padding: '12px 15px', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                <span>Giáo trình môn đại cương</span>
                <span style={{ color: '#4ade80', fontWeight: 'bold' }}>+26%</span>
              </div>
              <div style={{ background: '#1e293b', padding: '12px 15px', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                <span>Tai nghe và bàn phím học online</span>
                <span style={{ color: '#4ade80', fontWeight: 'bold' }}>+18%</span>
              </div>
              <div style={{ background: '#1e293b', padding: '12px 15px', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', fontSize: '14px' }}>
                <span>Quạt mini và bàn học phòng trọ</span>
                <span style={{ color: '#4ade80', fontWeight: 'bold' }}>+14%</span>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
            <div style={{ background: '#ffffff', padding: '20px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }}>
              <h4 style={{ fontSize: '20px', fontWeight: 'bold', margin: '0 0 5px 0', color: '#16a34a' }}>500+</h4>
              <p style={{ margin: 0, fontSize: '13px', color: '#64748b' }}>Sinh viên tham gia</p>
            </div>
            <div style={{ background: '#ffffff', padding: '20px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 2px 4px rgba(0,0,0,0.02)' }}>
              <h4 style={{ fontSize: '20px', fontWeight: 'bold', margin: '0 0 5px 0', color: '#16a34a' }}>98%</h4>
              <p style={{ margin: 0, fontSize: '13px', color: '#64748b' }}>Người dùng quay lại</p>
            </div>
          </div>

        </div>
      </div>

      {/* PHẦN DANH MỤC HOT */}
      <div style={{ maxWidth: '1200px', margin: '40px auto 0 auto', padding: '0 20px' }}>
        <p style={{ fontSize: '12px', fontWeight: '700', color: '#64748b', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '8px' }}>Danh mục hot</p>
        <h2 style={{ fontSize: '32px', fontWeight: '800', color: '#0f172a', marginBottom: '30px' }}>Chọn nhanh khu vực mua bán mà sinh viên vào nhiều nhất.</h2>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
          
          <div style={{ background: 'linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 100%)', padding: '30px', borderRadius: '16px', border: '1px solid #bae6fd' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <span style={{ background: '#0f172a', color: 'white', padding: '8px 12px', borderRadius: '8px', fontSize: '14px' }}>📚</span>
              <span style={{ fontSize: '13px', fontWeight: '600', color: '#0369a1' }}>234 tin</span>
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: '#0f172a', marginBottom: '10px' }}>Giáo trình</h3>
            <p style={{ fontSize: '14px', color: '#475569', marginBottom: '20px', lineHeight: '1.5' }}>Sách chuyên ngành, note môn học và bộ đề từ sinh viên khóa trên.</p>
            <Link to="/shop" style={{ color: '#0369a1', fontWeight: 'bold', textDecoration: 'none', fontSize: '14px' }}>Khám phá danh mục →</Link>
          </div>

          <div style={{ background: 'linear-gradient(135deg, #fef3c7 0%, #fffbeb 100%)', padding: '30px', borderRadius: '16px', border: '1px solid #fde68a' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <span style={{ background: '#0f172a', color: 'white', padding: '8px 12px', borderRadius: '8px', fontSize: '14px' }}>💻</span>
              <span style={{ fontSize: '13px', fontWeight: '600', color: '#b45309' }}>156 tin</span>
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: '#0f172a', marginBottom: '10px' }}>Đồ điện tử</h3>
            <p style={{ fontSize: '14px', color: '#475569', marginBottom: '20px', lineHeight: '1.5' }}>Laptop, máy tính bảng, phụ kiện học tập và đồ công nghệ đã qua sử dụng.</p>
            <Link to="/shop" style={{ color: '#b45309', fontWeight: 'bold', textDecoration: 'none', fontSize: '14px' }}>Khám phá danh mục →</Link>
          </div>

          <div style={{ background: 'linear-gradient(135deg, #dcfce7 0%, #f0fdf4 100%)', padding: '30px', borderRadius: '16px', border: '1px solid #bbf7d0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <span style={{ background: '#0f172a', color: 'white', padding: '8px 12px', borderRadius: '8px', fontSize: '14px' }}>🛏️</span>
              <span style={{ fontSize: '13px', fontWeight: '600', color: '#15803d' }}>189 tin</span>
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: '#0f172a', marginBottom: '10px' }}>Đồ phòng trọ</h3>
            <p style={{ fontSize: '14px', color: '#475569', marginBottom: '20px', lineHeight: '1.5' }}>Quạt, bàn học, đèn bàn, tủ mini và các món giúp ở trọ gọn gàng hơn.</p>
            <Link to="/shop" style={{ color: '#15803d', fontWeight: 'bold', textDecoration: 'none', fontSize: '14px' }}>Khám phá danh mục →</Link>
          </div>

          <div style={{ background: 'linear-gradient(135deg, #fce7f3 0%, #fdf2f8 100%)', padding: '30px', borderRadius: '16px', border: '1px solid #fbcfe8' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <span style={{ background: '#0f172a', color: 'white', padding: '8px 12px', borderRadius: '8px', fontSize: '14px' }}>✏️</span>
              <span style={{ fontSize: '13px', fontWeight: '600', color: '#be185d' }}>98 tin</span>
            </div>
            <h3 style={{ fontSize: '20px', fontWeight: 'bold', color: '#0f172a', marginBottom: '10px' }}>Dụng cụ học tập</h3>
            <p style={{ fontSize: '14px', color: '#475569', marginBottom: '20px', lineHeight: '1.5' }}>Máy tính cầm tay, bút vẽ, bảng viết và nhiều món phục vụ học nhóm.</p>
            <Link to="/shop" style={{ color: '#be185d', fontWeight: 'bold', textDecoration: 'none', fontSize: '14px' }}>Khám phá danh mục →</Link>
          </div>



          

        </div>
      </div>

    </div>
  );
}

export default Home;