import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';

function ProductDetail({ products, onDelete }) {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Tìm sản phẩm dựa vào ID trên URL
  const product = products.find((item) => item.id.toString() === id);

  if (!product) {
    return (
      <div style={{ textAlign: 'center', padding: '50px' }}>
        <h3>Không tìm thấy sản phẩm này!</h3>
        <Link to="/shop" style={{ color: '#2563eb', textDecoration: 'underline' }}>Quay lại cửa hàng</Link>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '900px', margin: '30px auto', padding: '20px', background: '#fff', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.08)', fontFamily: 'Arial, sans-serif' }}>
      <button 
        onClick={() => navigate(-1)} 
        style={{ background: '#f1f5f9', color: '#475569', border: 'none', padding: '8px 15px', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold', marginBottom: '20px' }}
      >
        ← Quay lại
      </button>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', alignItems: 'start' }}>
        {/* Hình ảnh sản phẩm */}
        <div style={{ borderRadius: '8px', overflow: 'hidden', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
          <img 
            src={product.image ? `http://localhost:5000${product.image}` : 'https://via.placeholder.com/400'} 
            alt={product.title} 
            style={{ width: '100%', height: '350px', objectFit: 'cover' }}
          />
        </div>

        {/* Thông tin chi tiết */}
        <div>
          <span style={{ fontSize: '13px', background: '#e0f2fe', color: '#0369a1', padding: '4px 10px', borderRadius: '4px', fontWeight: '600' }}>
            {product.category}
          </span>
          <h2 style={{ margin: '15px 0 10px 0', color: '#1e293b', fontSize: '24px' }}>{product.title}</h2>
          <p style={{ color: '#dc2626', fontWeight: 'bold', fontSize: '26px', margin: '0 0 20px 0' }}>
            {product.price} đ
          </p>

          <div style={{ background: '#f8fafc', padding: '15px', borderRadius: '8px', marginBottom: '20px', border: '1px solid #e2e8f0' }}>
            <p style={{ margin: '5px 0', color: '#475569' }}><strong>Tình trạng:</strong> {product.condition || 'Đã qua sử dụng'}</p>
            <p style={{ margin: '5px 0', color: '#475569' }}><strong>Số điện thoại liên hệ:</strong> <span style={{ color: '#2563eb', fontWeight: 'bold' }}>{product.phone || 'Chưa cập nhật'}</span></p>
          </div>

          {/* Nút liên hệ nhanh */}
          <a 
            href={`tel:${product.phone}`} 
            style={{ 
              display: 'block', 
              textAlign: 'center', 
              background: '#16a34a', 
              color: 'white', 
              padding: '12px 0', 
              borderRadius: '6px', 
              textDecoration: 'none', 
              fontWeight: 'bold', 
              fontSize: '16px',
              boxShadow: '0 2px 4px rgba(22, 163, 74, 0.2)'
            }}
          >
            📞 Gọi Ngay Cho Người Bán
          </a>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;