import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function PostProduct({ onAdd }) {
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('Sách vở');
  const [phone, setPhone] = useState('');
  const [image, setImage] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('title', title);
    formData.append('price', price);
    formData.append('category', category);
    formData.append('phone', phone);
    if (image) formData.append('image', image);

    onAdd(formData, () => {
      navigate('/shop');
    });
  };

  return (
    <div style={{ fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', background: '#f8fafc', minHeight: '90vh', padding: '40px 20px' }}>
      <div style={{ maxWidth: '650px', margin: '0 auto', background: '#ffffff', padding: '40px', borderRadius: '20px', boxShadow: '0 10px 30px rgba(0,0,0,0.04)', border: '1px solid #e2e8f0' }}>
        
        <span style={{ background: '#dcfce7', color: '#15803d', padding: '5px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '700' }}>
          ĐĂNG BÁN NHANH
        </span>
        <h2 style={{ fontSize: '28px', fontWeight: '800', color: '#0f172a', margin: '10px 0 8px 0' }}>Tạo tin rao bán món đồ của bạn</h2>
        <p style={{ color: '#64748b', fontSize: '14px', marginBottom: '30px' }}>Điền thông tin chi tiết để sinh viên khác dễ dàng liên hệ và mua hàng.</p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>Tên món đồ</label>
            <input 
              type="text" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              placeholder="Ví dụ: Giáo trình Giải tích 1, Máy tính Casio fx-580VN..." 
              required 
              style={{ width: '100%', padding: '12px 16px', borderRadius: '10px', border: '1px solid #cbd5e1', boxSizing: 'border-box', fontSize: '14px', outline: 'none' }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>Giá bán (VNĐ)</label>
              <input 
                type="text" 
                value={price} 
                onChange={(e) => setPrice(e.target.value)} 
                placeholder="Ví dụ: 50.000" 
                required 
                style={{ width: '100%', padding: '12px 16px', borderRadius: '10px', border: '1px solid #cbd5e1', boxSizing: 'border-box', fontSize: '14px', outline: 'none' }}
              />
            </div>
            <div>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>Danh mục</label>
              <select 
                value={category} 
                onChange={(e) => setCategory(e.target.value)} 
                style={{ width: '100%', padding: '12px 16px', borderRadius: '10px', border: '1px solid #cbd5e1', boxSizing: 'border-box', background: '#fff', fontSize: '14px', outline: 'none' }}
              >
                <option value="Giáo trình">Giáo trình</option>
                <option value="Đồ điện tử">Đồ điện tử</option>
                <option value="Đồ phòng trọ">Đồ phòng trọ</option>
                <option value="Dụng cụ học tập">Dụng cụ học tập</option>
              </select>
            </div>
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>Số điện thoại / Zalo liên hệ</label>
            <input 
              type="text" 
              value={phone} 
              onChange={(e) => setPhone(e.target.value)} 
              placeholder="Nhập số điện thoại để người mua gọi trực tiếp" 
              required 
              style={{ width: '100%', padding: '12px 16px', borderRadius: '10px', border: '1px solid #cbd5e1', boxSizing: 'border-box', fontSize: '14px', outline: 'none' }}
            />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>Hình ảnh sản phẩm</label>
            <input 
              type="file" 
              onChange={(e) => setImage(e.target.files[0])} 
              style={{ width: '100%', padding: '10px', borderRadius: '10px', border: '1px solid #cbd5e1', background: '#f8fafc', fontSize: '14px' }}
            />
          </div>

          <button 
            type="submit" 
            style={{ background: '#16a34a', color: 'white', border: 'none', padding: '14px', borderRadius: '12px', fontSize: '16px', fontWeight: '700', cursor: 'pointer', marginTop: '10px', boxShadow: '0 4px 12px rgba(22, 163, 74, 0.25)' }}
          >
            Đăng bài ngay
          </button>
        </form>
      </div>
    </div>
  );
}

export default PostProduct;