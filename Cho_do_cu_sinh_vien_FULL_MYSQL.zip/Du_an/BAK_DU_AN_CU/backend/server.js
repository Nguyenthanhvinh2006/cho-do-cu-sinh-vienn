const express = require('express'); // Import framework Express để xây dựng server
const mysql = require('mysql2'); // Import thư viện kết nối cơ sở dữ liệu MySQL
const cors = require('cors'); // Import cors để cho phép React (cổng 5173) gọi API đến Node.js (cổng 5000)
const multer = require('multer'); // Import multer để xử lý việc tải và lưu file ảnh từ máy tính lên server
const path = require('path'); // Import thư viện path chuẩn của Node.js để xử lý đường dẫn tệp tin

const app = express(); // Khởi tạo ứng dụng Express
app.use(express.json()); // Middleware giúp server đọc được dữ liệu dạng JSON gửi lên từ client
app.use(cors()); // Kích hoạt CORS cho toàn bộ ứng dụng

// Cấu hình nơi lưu trữ và cách đặt tên cho file ảnh tải lên
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Chỉ định thư mục lưu trữ ảnh trên server là thư mục 'uploads'
  },
  filename: (req, file, cb) => {
    // Đặt tên file bằng thời gian hiện tại (timestamp) + phần mở rộng cũ để tránh bị trùng lặp tên ảnh
    cb(null, Date.now() + path.extname(file.originalname)); 
  },
});
const upload = multer({ storage: storage }); // Khởi tạo middleware upload dựa trên cấu hình storage trên

// Cho phép trình duyệt truy cập công khai vào thư mục 'uploads' để hiển thị hình ảnh
app.use('/uploads', express.static('uploads'));

// Thiết lập kết nối đến cơ sở dữ liệu MySQL
const db = mysql.createConnection({
  host: 'localhost', // Địa chỉ máy chủ database (máy tính cá nhân)
  user: 'root', // Tài khoản truy cập MySQL
  password: '170906', // Mật khẩu truy cập MySQL của bạn
  database: 'cho_sinh_vien' // Tên cơ sở dữ liệu đã tạo
});

// API phương thức GET: Lấy toàn bộ danh sách sản phẩm từ database, sắp xếp mới nhất lên đầu
app.get('/api/products', (req, res) => {
  db.query('SELECT * FROM products ORDER BY id DESC', (err, results) => {
    if (err) return res.status(500).json(err); // Nếu lỗi truy vấn, trả về mã lỗi 500
    res.json(results); // Trả về danh sách sản phẩm dưới dạng JSON cho React
  });
});

// API phương thức POST: Thêm sản phẩm mới (có hỗ trợ nhận 1 file ảnh qua multer)
app.post('/api/products', upload.single('image'), (req, res) => {
  const { title, price, category, condition, phone } = req.body; // Lấy dữ liệu chữ từ request body
  
  // Nếu có file ảnh được tải lên, tạo đường dẫn tương đối; nếu không thì để chuỗi rỗng
  const image = req.file ? `/uploads/${req.file.filename}` : '';

  // Câu lệnh SQL chèn dữ liệu sản phẩm mới vào bảng products
  const sql = 'INSERT INTO products (title, price, category, `condition`, phone, image) VALUES (?, ?, ?, ?, ?, ?)';
  
  db.query(sql, [title, price, category, condition, phone, image], (err, result) => {
    if (err) return res.status(500).json(err); // Trả về lỗi nếu câu lệnh SQL gặp sự cố
    // Trả về thông tin sản phẩm vừa được lưu thành công kèm theo ID tự tăng và đường dẫn ảnh
    res.json({ id: result.insertId, title, price, category, condition, phone, image });
  });
});

// API phương thức DELETE: Xóa sản phẩm dựa vào ID được truyền trên URL
app.delete('/api/products/:id', (req, res) => {
  const { id } = req.params; // Lấy ID sản phẩm từ tham số trên đường dẫn
  const sql = 'DELETE FROM products WHERE id = ?'; // Câu lệnh SQL xóa sản phẩm theo ID
  
  db.query(sql, [id], (err, result) => {
    if (err) return res.status(500).json(err); // Báo lỗi nếu xóa thất bại
    res.json({ message: 'Xóa thành công', id }); // Xác nhận xóa thành công
  });
});

// Khởi động server lắng nghe tại cổng 5000
app.listen(5000, () => {
  console.log('Server Backend đang chạy tại cổng 5000');
});

// API Đăng nhập tài khoản
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  // Câu lệnh SQL kiểm tra thông tin username và password trong cơ sở dữ liệu
  const sql = 'SELECT * FROM users WHERE username = ? AND password = ?';
  db.query(sql, [username, password], (err, results) => {
    if (err) return res.status(500).json(err);

    // Nếu tìm thấy tài khoản khớp
    if (results.length > 0) {
      const user = results[0];
      res.json({
        success: true,
        message: 'Đăng nhập thành công',
        role: user.role, // Trả về quyền hạn: 'admin' hoặc 'user'
        username: user.username
      });
    } else {
      // Nếu không tìm thấy hoặc sai tài khoản/mật khẩu
      res.status(401).json({ success: false, message: 'Sai tài khoản hoặc mật khẩu!' });
    }
  });
});