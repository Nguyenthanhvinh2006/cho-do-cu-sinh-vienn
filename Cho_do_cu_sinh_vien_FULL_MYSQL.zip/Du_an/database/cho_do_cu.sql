CREATE DATABASE IF NOT EXISTS cho_do_cu
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cho_do_cu;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS product_images;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL DEFAULT '123456',
  rating DECIMAL(2,1) NOT NULL DEFAULT 5.0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(12,0) NOT NULL,
  condition_status ENUM('Mới','Đã sử dụng') NOT NULL DEFAULT 'Đã sử dụng',
  category_id INT NOT NULL,
  area VARCHAR(100) NOT NULL,
  seller_id INT NOT NULL,
  status ENUM('active','sold','hidden','pending') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id),
  FOREIGN KEY (seller_id) REFERENCES users(id)
);

CREATE TABLE product_images (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  image_url VARCHAR(500) NOT NULL,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE favorites (
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(user_id, product_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE TABLE messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  product_id INT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(sender_id) REFERENCES users(id),
  FOREIGN KEY(receiver_id) REFERENCES users(id),
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
);

CREATE TABLE reports (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  reporter_id INT NOT NULL,
  reason VARCHAR(200) NOT NULL,
  note TEXT,
  status ENUM('pending','approved','removed') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY(reporter_id) REFERENCES users(id)
);

INSERT INTO users(name,email,password,rating) VALUES
('Nguyễn Văn An','an@student.edu.vn','123456',4.8),
('Trần Minh Đức','duc@student.edu.vn','123456',4.6),
('Lê Thu Hà','ha@student.edu.vn','123456',4.9),
('Phạm Minh Quân','quan@student.edu.vn','123456',4.7);

INSERT INTO categories(name) VALUES
('Sách'),('Xe đạp'),('Đồ học tập'),('Điện tử'),('Thời trang');

INSERT INTO products(title,description,price,condition_status,category_id,area,seller_id,status) VALUES
('Giáo trình Lập trình Web','Giáo trình còn tốt, phù hợp sinh viên CNTT.',70000,'Đã sử dụng',1,'Cầu Giấy',1,'active'),
('Xe đạp sinh viên','Xe đạp đi học, hoạt động tốt, bảo dưỡng định kỳ.',850000,'Đã sử dụng',2,'Thanh Xuân',2,'active'),
('Balo laptop 15.6 inch','Balo chống sốc, nhiều ngăn, dùng ít.',180000,'Mới',3,'Đống Đa',3,'active'),
('Tai nghe Bluetooth','Tai nghe không dây, pin tốt, đầy đủ hộp.',320000,'Đã sử dụng',4,'Cầu Giấy',4,'active'),
('Áo khoác sinh viên','Áo khoác còn mới, size M.',150000,'Đã sử dụng',5,'Hai Bà Trưng',1,'active'),
('Máy tính Casio FX-580VN X','Máy tính chính hãng, hoạt động bình thường.',350000,'Đã sử dụng',3,'Thanh Xuân',2,'sold');

INSERT INTO product_images(product_id,image_url) VALUES
(1,'/uploads/default-book.jpg'),
(2,'/uploads/default-bike.jpg'),
(3,'/uploads/default-backpack.jpg'),
(4,'/uploads/default-headphone.jpg'),
(5,'/uploads/default-jacket.jpg'),
(6,'/uploads/default-calculator.jpg');

INSERT INTO favorites(user_id,product_id) VALUES
(2,1),(3,2),(4,3);

INSERT INTO messages(sender_id,receiver_id,product_id,content) VALUES
(2,1,1,'Chào bạn, giáo trình còn không?'),
(1,2,1,'Chào bạn, sản phẩm vẫn còn nhé.');

INSERT INTO reports(product_id,reporter_id,reason,note,status) VALUES
(2,3,'Giá không đúng','Đề nghị kiểm tra thông tin giá.','pending');
